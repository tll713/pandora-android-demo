package com.pandora.demo;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.ActivityNotFoundException;
import android.os.Bundle;
import android.graphics.Color;
import android.net.Uri;
import android.view.View;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.ValueCallback;
import android.widget.Toast;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.HashSet;
import java.util.Arrays;

public final class MainActivity extends Activity {
    private WebView web;
    private ValueCallback<Uri[]> fileCallback;
    private static final int AVATAR_REQUEST = 101;
    private static final String ORIGIN = "appassets.androidplatform.net";
    private static final Set<String> FILES = new HashSet<>(Arrays.asList("index.html", "favicon.svg", "src/app.js", "src/domain.js", "src/style.css", "src/mobile.css"));
    // 默认后端地址（电脑的局域网 IP+端口）；连不上时可在 App 登录页的“服务器设置”里修改
    private static final String API_BASE = "http://10.231.158.160:8080/api";

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(247, 249, 246));
        getWindow().setNavigationBarColor(Color.WHITE);
        // 状态栏使用深色图标，避免浅色背景上看不清时间与电量
        // 注意：Window.getInsetsController() 在 onCreate 早期可能返回 null，这里改用 decor 视图设置，避免空指针闪退
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        web = new WebView(this);
        web.setBackgroundColor(Color.rgb(247, 249, 246));
        // Android 15 起强制 edge-to-edge，WebView 不支持 env(safe-area-inset-*)，
        // 这里直接按系统资源读取状态栏/导航栏高度给 WebView 加内边距，避免内容被系统栏遮挡
        int density = Math.max(1, getResources().getDisplayMetrics().densityDpi / 160);
        int topInset = systemBarHeight("status_bar_height", 24 * density) + 8 * density;
        int bottomInset = systemBarHeight("navigation_bar_height", 0) + 4 * density;
        web.setPadding(0, topInset, 0, bottomInset);
        setContentView(web);
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        settings.setUserAgentString(settings.getUserAgentString() + " PandoraAndroid/0.4.4");
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("image/*");
                intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"image/jpeg", "image/png", "image/webp"});
                try { startActivityForResult(intent, AVATAR_REQUEST); }
                catch (ActivityNotFoundException e) {
                    fileCallback.onReceiveValue(null); fileCallback = null;
                    Toast.makeText(MainActivity.this, "未找到可用的图片选择器", Toast.LENGTH_SHORT).show();
                }
                return true;
            }
        });
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                return false;
            }
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest req) {
                Uri url = req.getUrl();
                // 本地资源由本应用提供；网络请求（后端 API）交给系统网络栈处理，
                // 这样用户在登录页修改服务器地址后也能正常访问
                if (!isLocal(url)) {
                    String scheme = url.getScheme();
                    if ("http".equals(scheme) || "https".equals(scheme)) return null;
                    return response(403, "Forbidden", "text/plain", "External requests disabled");
                }
                String path = req.getUrl().getPath();
                String file = path.equals("/") ? "index.html" : path.substring(1);
                if (!FILES.contains(file)) return response(404, "Not Found", "text/plain", "Not found");
                try {
                    String mime = file.endsWith(".js") ? "text/javascript" : file.endsWith(".css") ? "text/css" : file.endsWith(".svg") ? "image/svg+xml" : "text/html";
                    Map<String, String> headers = new HashMap<>();
                    String csp = "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; connect-src 'self' http: https:; object-src 'none'; base-uri 'self'";
                    InputStream body;
                    if (file.equals("index.html")) {
                        // 在页面脚本执行前注入 API 基地址；nonce 保证 CSP 下仅这段内联脚本可执行
                        InputStream in = getAssets().open("web/" + file);
                        java.io.ByteArrayOutputStream buffer = new java.io.ByteArrayOutputStream();
                        byte[] chunk = new byte[4096];
                        int n;
                        while ((n = in.read(chunk)) != -1) buffer.write(chunk, 0, n);
                        in.close();
                        String html = new String(buffer.toByteArray(), java.nio.charset.StandardCharsets.UTF_8);
                        String nonce = java.util.UUID.randomUUID().toString();
                        html = html.replace("<head>", "<head><script nonce=\"" + nonce + "\">window.__PANDORA_API_BASE__=\"" + API_BASE + "\";</script>");
                        csp = csp.replace("script-src 'self'", "script-src 'self' 'nonce-" + nonce + "'");
                        body = new ByteArrayInputStream(html.getBytes(java.nio.charset.StandardCharsets.UTF_8));
                    } else {
                        body = getAssets().open("web/" + file);
                    }
                    headers.put("Content-Security-Policy", csp);
                    headers.put("X-Content-Type-Options", "nosniff");
                    return new WebResourceResponse(mime, "UTF-8", 200, "OK", headers, body);
                } catch (Exception e) { return response(500, "Error", "text/plain", "Local resource unavailable"); }
            }
        });
        web.loadUrl("https://" + ORIGIN + "/index.html");
    }
    private boolean isLocal(Uri url) { return "https".equals(url.getScheme()) && ORIGIN.equals(url.getHost()); }
    /** 读取系统栏高度，取不到时使用兜底值 */
    private int systemBarHeight(String name, int fallback) {
        try {
            int resId = getResources().getIdentifier(name, "dimen", "android");
            if (resId > 0) {
                int value = getResources().getDimensionPixelSize(resId);
                if (value > 0) return value;
            }
        } catch (Exception ignored) { }
        return fallback;
    }
    private WebResourceResponse response(int status, String reason, String mime, String text) {
        return new WebResourceResponse(mime, "UTF-8", status, reason, new HashMap<>(), new ByteArrayInputStream(text.getBytes(java.nio.charset.StandardCharsets.UTF_8)));
    }
    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == AVATAR_REQUEST && fileCallback != null) {
            fileCallback.onReceiveValue(resultCode == RESULT_OK && data != null && data.getData() != null ? new Uri[]{data.getData()} : null);
            fileCallback = null;
        }
    }
    @Override public void onBackPressed() {
        web.evaluateJavascript("Boolean(window.pandoraBack && window.pandoraBack())", result -> {
            if (!"true".equals(result)) new AlertDialog.Builder(this).setTitle("退出潘多拉？").setMessage("确认关闭当前应用吗？")
                .setPositiveButton("退出", (dialog, which) -> finish()).setNegativeButton("继续使用", null).show();
        });
    }
    @Override protected void onDestroy() { if (fileCallback != null) {fileCallback.onReceiveValue(null);fileCallback=null;} web.destroy(); super.onDestroy(); }
}
